<h1>This is nav bar btw</h1>
<ul>
    <li><a href="/">Home</a></li>
    <li><a href="/about">about</a></li>
    <li><a href="/projects">projects</a></li>
    <li><a href="/contact">contact</a></li>
</ul>

<hr>
<hr> 
<?php echo $__env->yieldContent("content"); ?>