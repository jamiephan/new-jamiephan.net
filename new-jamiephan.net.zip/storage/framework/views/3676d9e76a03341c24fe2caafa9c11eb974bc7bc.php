<?php $__env->startSection("content"); ?>
<pre>
You used to call me on my, you used to, you used to
You used to call me on my cell phone
Late night when you need my love
Call me on my cell phone
Late night when you need my love
I know when that hotline bling
That can only mean one thing
I know when that hotline bling
That can only mean one thing
Ever since I left the city you
Got a reputation for yourself now
Everybody knows and I feel left out
Girl you got me down, you got me stressed out
Cause ever since I left the city, you
Started wearing less and goin' out more
Glasses of champagne out on the dance floor
Hangin' with some girls I've never seen before
You used to call me on my cell phone
Late night when you need my love
Call me on my cell phone
Late night when you need my love
I know when that hotline bling
That can only mean one thing
I know when that hotline bling
That can only mean one thing
Ever since I left the city, you, you, you
You and me we just don't get along
You make me feel like I did you wrong
Going places where you don't belong
Ever since I left the city, you
You got exactly what you asked for
Running out of pages in your passport
Hanging with some girls I've never seen before
You used to call me on my cell phone
Late night when you need my love
Call me on my cell phone
Late night when you need my love
I know when that hotline bling
That can only mean one thing
I know when that hotline bling
That can only mean one thing
These days, all I do is
Wonder if you bendin' over backwards for someone else
Wonder if your rollin' backwoods for someone else
Doing things I taught you gettin' nasty for someone else
You don't need no one else
You don't need nobody else, no
Why you never alone
Why you always touching road
Used to always stay at home, be a good girl
You was in the zone
You should just be yourself
Right now, you're someone else
You used to call me on my cell phone
Late night when you need my love
Call me on my cell phone
Late night when you need my love
I know when that hotline bling
That can only mean one thing
I know when that hotline bling
That can only mean one thing
Ever since I left the city
</pre>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Index.inc.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>