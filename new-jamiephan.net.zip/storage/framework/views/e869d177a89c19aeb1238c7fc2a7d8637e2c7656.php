<?php $__env->startSection("content"); ?>
wheeeeeeeeee so many projects!
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Index.inc.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>