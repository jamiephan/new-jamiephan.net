@extends("Index.inc.navbar")

@section("content")
wheeeeeeeeee so many projects!
@endsection