@extends("Index.inc.navbar")

@section("content")
aboutty!!!!!
@endsection