@extends("Index.inc.navbar")

@section("content")
indexy!!!
@endsection